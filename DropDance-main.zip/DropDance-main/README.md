# DropDance
simple web animation project using html,css, javascript.
Features:
Dynamic drop creation with randomized positions.
Smooth transitions and color transformations using CSS animations.
Interactive and responsive visuals for a lively user experience.
Built with HTML, CSS, and JavaScript.
Drops are randomly positioned across the screen at regular intervals.
Each drop animates through size, shape, and color changes, creating a captivating effect.
The drops are removed after their animation ends to keep the screen clutter-free.
